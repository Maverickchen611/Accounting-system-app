package com.example.accountingsystem;

public class Income{
    private int incomeId;
    private myDate date;
    private String category;
    private String item;
    private double amount;
    private Clock time;
    private String description;

    private int reportId;

    public Income(int incomeId, myDate date, String category, String item, double amount, String description, Clock time,int reportId) {
        this.incomeId = incomeId;
        this.date = date;
        this.category = category;
        this.item = item;
        this.amount = amount;
        this.description = description;
        this.time = time;
        this.reportId = reportId;
    }

    public Income(){
        this.date = new myDate();
        this.time = new Clock();
    }

    public void insertData(DBHelper db){
        int rowId = (int) db.insertIncomeData(date.toString() ,category, item, amount, description,time.toString() ,reportId);
        if(rowId != -1){
            this.incomeId = rowId;
            System.out.println( toString()+ " insert success");
        }
        else{
            System.out.println( toString()+ " insert failed");
        }
    }

    public Income getIncomeById(DBHelper db, int incomeId){
        Income existIncome = db.getIncomeById(incomeId);
        if(existIncome != null){
            return existIncome;
        }
        return  null;
    }

    public Income updateIncomeById(DBHelper db,int incomeId, String category, String item, double amount, String description){
        Income tmpIncome = null;
        if(db.updateIncomeData(incomeId,category,item,amount,description)){
            tmpIncome = getIncomeById(db, incomeId);
            System.out.println("Income update success");
            System.out.println(tmpIncome.toString());
        }
        else{
            System.out.println("Income update failed, id not found");
        }
        return tmpIncome;
    }


    public int getIncomeId() {
        return incomeId;
    }

    public void setIncomeId(int incomeId) {
        this.incomeId = incomeId;
    }

    public myDate getDate() {
        return date;
    }

    public void setDate(myDate date) {
        this.date = date;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getItem() {
        return item;
    }

    public void setItem(String item) {this.item = item;}

    public Clock getTime() {
        return time;
    }

    public void setTime(Clock time) {
        this.time = time;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getIncomeReportId() {
        return incomeId;
    }

    public void setIncomeReportId(int reportId) {
        this.reportId = reportId;
    }

    @Override
    public String toString() {
        return  "Income{ " +
                "Income ID: " + incomeId +
                ", Date: " + date +
                ", Category: " + category +
                ", Item: " + item +
                ", Amount: " + amount +
                ", Description: " + description +
                ", Report ID: " + reportId +" }";
    }
}
