package com.example.accountingsystem;

import android.graphics.Color;
import android.os.Bundle;

import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.github.mikephil.charting.animation.Easing;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.highlight.Highlight;
import com.github.mikephil.charting.listener.OnChartValueSelectedListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class incomeact extends Fragment {

    DBHelper dbHelper;
    PieChart pieChart;
    Account account;
    Report report;
    myDate date;
    View view;
    private LinearLayout mainLinearLayout;
    private List<View> addedViews;

    public incomeact(Account account, myDate date){
        this.account =account;
        this.date = date;
    }

    public void setDate(myDate date){
        this.date = date;

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        addedViews = new ArrayList<>();

        view = inflater.inflate(R.layout.fragment_income2, container, false);
        mainLinearLayout = view.findViewById(R.id.income_fragment_linear);
        dbHelper = new DBHelper(getActivity());


        Toast.makeText(getContext(), "Received result: " + account.toString(), Toast.LENGTH_SHORT).show();
        refreshPieChart();
        //createList();
        return view;
    }

    private void createList(){
        LayoutInflater itemTemplateInflater = getLayoutInflater();
        Report tmpReport = account.getReportsByAccountIdAndDate(dbHelper,account.getAccountId(),date.toMonthString());
        System.out.println(tmpReport.toString());

        tmpReport.setIncomeByReportId(dbHelper,report.getReportId());
        List<Income> tmpIncomeList = tmpReport.getIncomeList();

        if(tmpIncomeList.isEmpty()){
            addedViews = new ArrayList<>();
            View itemTemplateView = itemTemplateInflater.inflate(R.layout.item_template_1, null);
            //LinearLayout itemLinearLayout = itemTemplateView.findViewById(R.id.itemTemplateLinaer);
            // Find the TextViews in the inflated layout
            TextView topLeftTextView = itemTemplateView.findViewById(R.id.top_left);
            TextView bottomLeftTextView = itemTemplateView.findViewById(R.id.bottom_left);
            TextView topRightTextView = itemTemplateView.findViewById(R.id.top_right);
            TextView bottomRightTextView = itemTemplateView.findViewById(R.id.bottom_right);

            // Set the desired text for each TextView
            System.out.println("no data in "+date.toString());
            topLeftTextView.setText("no data");
            bottomLeftTextView.setText("no data");
            topRightTextView.setText("no data");
            bottomRightTextView.setText("no data");
            addedViews.add(itemTemplateView);
            mainLinearLayout.addView(itemTemplateView); // Add the itemTemplateView to the linearLayout

        }
        else {
            addedViews = new ArrayList<>();
        }
        int IncomeCount = tmpIncomeList.size()-1;

        Map<String ,Double> categoryMap = getIncomeListToMap();

        for (Map.Entry<String, Double> entry : categoryMap.entrySet()) {

            System.out.println("IncomeCount: "+ IncomeCount);

            View itemTemplateViewIncome = itemTemplateInflater.inflate(R.layout.item_template_1, null);

            TextView topLeftTextViewIncome = itemTemplateViewIncome.findViewById(R.id.top_left);
            TextView bottomLeftTextViewIncome = itemTemplateViewIncome.findViewById(R.id.bottom_left);
            TextView topRightTextViewIncome = itemTemplateViewIncome.findViewById(R.id.top_right);
            TextView bottomRightTextViewIncome = itemTemplateViewIncome.findViewById(R.id.bottom_right);


            String key = entry.getKey();
            Double value = entry.getValue();
            topLeftTextViewIncome.setVisibility(View.GONE);
            topRightTextViewIncome.setVisibility(View.GONE);
            bottomLeftTextViewIncome.setText(key.toString());
            //topRightTextViewIncome.setVisibility(View.INVISIBLE);
            //topRightTextViewIncome.setText("");
            bottomRightTextViewIncome.setTextColor((ContextCompat.getColor( getActivity(), R.color.dark_red)));
            bottomRightTextViewIncome.setText("-"+Double.toString(value));

            //itemLinearLayout.setBackgroundColor(ContextCompat.getColor(this, R.color.pink));
            mainLinearLayout.addView(itemTemplateViewIncome); // Add the itemTemplateViewIncome to the linearLayout
            addedViews.add(itemTemplateViewIncome);

        }
        while(IncomeCount >-1){
            System.out.println("IncomeCount: "+ IncomeCount);

            View itemTemplateViewIncome = itemTemplateInflater.inflate(R.layout.item_template_3, null);

            TextView topLeftTextViewIncome = itemTemplateViewIncome.findViewById(R.id.top_left);
            TextView bottomLeftTextViewIncome = itemTemplateViewIncome.findViewById(R.id.bottom_left);
            TextView topRightTextViewIncome = itemTemplateViewIncome.findViewById(R.id.top_right);
            TextView bottomRightTextViewIncome = itemTemplateViewIncome.findViewById(R.id.bottom_right);
            //LinearLayout itemLinearLayout = itemTemplateViewIncome.findViewById(R.id.itemTemplateLinaer);
            Income tmpIncome = new Income();
            if (  IncomeCount >= 0 && IncomeCount < tmpIncomeList.size() ) {
                tmpIncome = tmpIncomeList.get(IncomeCount);
                IncomeCount--;
            }
            // Set the desired text for each TextView


        }
        //setButtonClickListener();
    }

    private void releaseList(){
        if(addedViews == null){
            return;
        }
        for (int i = 0; i < addedViews.size(); i++) {
            View viewToRemove = addedViews.get(i);
            mainLinearLayout.removeView(viewToRemove);
        }
        addedViews = null;
    }
    public void refreshPieChart() {
        releaseList();
        report = new Account().getReportsByAccountIdAndDate(dbHelper,account.getAccountId(), date.toMonthString());
        pieChart = view.findViewById(R.id.pieChart_view);
        pieChart.setHoleColor(Color.parseColor("#000000"));
        pieChart.setOnChartValueSelectedListener(new incomeact.PieChartOnChartValueSelectedListener());
        initPieChart();
        showPieChart(getIncomeListToMap());
        pieChart.getDescription().setEnabled(false);
        pieChart.setDrawEntryLabels(true);
        createList();
    }

    private Map<String, Double> getIncomeListToMap(){
        Map<String,Double> tmpMap = new HashMap<>();
        List<Income> tmpIncomeList = report.getIncomeByReportId(dbHelper, report.getReportId());
        for(int i =0; i< tmpIncomeList.size(); i++){
            Income tmpIncome = tmpIncomeList.get(i);
            String category = tmpIncome.getCategory();
            double amount = tmpIncome.getAmount();
            if(tmpMap.containsKey(category)){
                amount = tmpMap.get(category) + amount;
            }
            tmpMap.put(category, amount);
        }
        return tmpMap;
    }
    private void showPieChart(Map<String, Double> typeAmountMap){

        ArrayList<PieEntry> pieEntries = new ArrayList<>();
        String label = "type";
        //typeAmountMap = getIncomeListToMap();
        //initializing data
        if(typeAmountMap.isEmpty()){
            typeAmountMap.put("no Data",1.0);
        }

        /*Map<String, Double> typeAmountMap = new HashMap<>();
        typeAmountMap.put("Toys", 200.0);
        typeAmountMap.put("Snacks", 230.0);
        typeAmountMap.put("Clothes", 100.0);
        typeAmountMap.put("Stationary", 500.0);
        typeAmountMap.put("Phone", 50.0);*/


        //initializing colors for the entries
        ArrayList<Integer> colors = new ArrayList<>();
        colors.add(Color.parseColor("#304567"));
        colors.add(Color.parseColor("#309967"));
        colors.add(Color.parseColor("#476567"));
        colors.add(Color.parseColor("#890567"));
        colors.add(Color.parseColor("#a35567"));
        colors.add(Color.parseColor("#ff5f67"));
        colors.add(Color.parseColor("#3ca567"));

        //input data and fit data into pie chart entry
        for(String type: typeAmountMap.keySet()){
            pieEntries.add(new PieEntry(typeAmountMap.get(type).floatValue(), type));
        }

        //collecting the entries with label name
        PieDataSet pieDataSet = new PieDataSet(pieEntries,label);
        //setting text size of the value
        pieDataSet.setValueTextSize(12f);
        //providing color list for coloring different entries
        pieDataSet.setColors(colors);
        //grouping the data set from entry to chart
        PieData pieData = new PieData(pieDataSet);
        //showing the value of the entries, default true if not set
        pieData.setDrawValues(true);

        pieChart.setData(pieData);
        pieChart.invalidate();
    }
    private void initPieChart(){
        //using percentage as values instead of amount
        pieChart.setUsePercentValues(true);

        //remove the description label on the lower left corner, default true if not set
        pieChart.getDescription().setEnabled(false);

        //enabling the user to rotate the chart, default true
        pieChart.setRotationEnabled(true);
        //Set this to true to draw the entry labels into the pie slices.

        //adding friction when rotating the pie chart
        pieChart.setDragDecelerationFrictionCoef(0.9f);
        //setting the first entry start from right hand side, default starting from top
        pieChart.setRotationAngle(0);

        //highlight the entry when it is tapped, default true if not set
        pieChart.setHighlightPerTapEnabled(true);
        //adding animation so the entries pop up from 0 degree
        pieChart.animateY(1400, Easing.EaseInOutQuad);
        //setting the color of the hole in the middle, default white
        pieChart.setHoleColor(Color.parseColor("#ffffff"));

    }
    private class PieChartOnChartValueSelectedListener implements OnChartValueSelectedListener {

        @Override
        public void onValueSelected(Entry e, Highlight h) {
            // Trigger activities when entry is clicked
        }

        @Override
        public void onNothingSelected() {

        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {super.onCreate(savedInstanceState);}

}