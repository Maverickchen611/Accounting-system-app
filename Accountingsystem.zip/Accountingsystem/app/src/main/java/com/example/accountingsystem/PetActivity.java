package com.example.accountingsystem;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.DeadObjectException;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class PetActivity extends AppCompatActivity {

    private Button goodFeedBtn,catTeaserBtn,normalFeedBtn,grass_btn;
    private TextView coinTv, statusTv,emotionTv;
    private ImageView petImage,coinImage;

    private int coinNum;
    private   Intent intent;

    private CatEmotion currentEmotion;
    private HungerLevel currentHungerLevel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pet_layout);

        intent = getIntent();
        coinNum = intent.getIntExtra("coinNum", 0); // Replace "intKey" with the same key used in MainActivity

        initialLayout();
        setButtonClickListener();
    }


    private void initialLayout() {
        goodFeedBtn = findViewById(R.id.good_feed_btn);
        catTeaserBtn = findViewById(R.id.cat_teaser_btn);
        normalFeedBtn = findViewById(R.id.normal_feed_btn);
        grass_btn =findViewById(R.id.grass_btn);
        coinTv =findViewById(R.id.tv_coin_number);
        statusTv =findViewById(R.id.tv_current_status);
        emotionTv =findViewById(R.id.tv_current_emotion);
        petImage = findViewById(R.id.cat_image);
        coinImage = findViewById(R.id.coin_image);
        //setCoin();
        setEmotion();
        setHunger();
        setTextView();


    }


    private void setButtonClickListener() {
        goodFeedBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (currentHungerLevel == HungerLevel.SATIATED) {
                    Toast.makeText(getApplicationContext(), "You Pet is full", Toast.LENGTH_SHORT).show();
                }
                else if(coinNum >= 20) {
                    coinNum -= 20;
                    currentHungerLevel = currentHungerLevel.SATIATED;
                }else{
                    Toast.makeText(getApplicationContext(), "You can't afford it ", Toast.LENGTH_SHORT).show();

                }
                setTextView();

            }
        });
        catTeaserBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                if (currentEmotion == CatEmotion.SATISFIED){
                    Toast.makeText(getApplicationContext(), "You Pet is SATISFIED", Toast.LENGTH_SHORT).show();
                }
                if(coinNum >= 20) {
                    coinNum -= 20;
                    currentEmotion = increaseCatEmotion(currentEmotion);
                }
                else{
                    Toast.makeText(getApplicationContext(), "You can't afford it ", Toast.LENGTH_SHORT).show();
                    }
                setTextView();


            }
        });
        normalFeedBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (currentHungerLevel == HungerLevel.SATIATED) {
                    Toast.makeText(getApplicationContext(), "You Pet is full", Toast.LENGTH_SHORT).show();
                }
                else if(coinNum >= 5){
                    coinNum-=5;
                    currentHungerLevel = increaseHungerLevel(currentHungerLevel);
                }else{
                    Toast.makeText(getApplicationContext(), "You can't afford it ", Toast.LENGTH_SHORT).show();

                }
                setTextView();

            }
        });
        grass_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (currentEmotion == CatEmotion.SATISFIED){
                    Toast.makeText(getApplicationContext(), "You Pet is SATISFIED", Toast.LENGTH_SHORT).show();
                }
                else if(coinNum >= 30){
                    coinNum-=30;
                    currentEmotion = CatEmotion.SATISFIED;
                }else{
                    Toast.makeText(getApplicationContext(), "You can't afford it ", Toast.LENGTH_SHORT).show();

                }
                setTextView();

            }
        });

        petImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Random random = new Random();
                int randomNumber = random.nextInt(10); // Generate random number between 0 and 9
                if(randomNumber < 3){
                    currentEmotion = increaseCatEmotion(currentEmotion);
                    currentHungerLevel = decreaseHungerLevel(currentHungerLevel);
                    currentHungerLevel = decreaseHungerLevel(currentHungerLevel);
                }else{
                    currentEmotion = decreaseCatEmotion(currentEmotion);
                    currentHungerLevel = decreaseHungerLevel(currentHungerLevel);
                }
                setTextView();

            }
        });
        coinImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent();
                intent.putExtra("updatedValue", coinNum);
                setResult(RESULT_OK, intent);
                finish();
                //coinNum+=5;
                setTextView();
            }
        });
    }

    public void setTextView(){
        coinTv.setText(Integer.toString(coinNum));
        emotionTv.setText(getCatEmotionTranslation());
        statusTv.setText(getHungerLevelTranslation());
    }


    public String getHungerLevelTranslation( ) {
        String translation;

        switch (currentHungerLevel) {
            case SATIATED:
                translation = "飽足 4";
                break;
            case SATISFIED:
                translation = "滿意 3";
                break;
            case HUNGRY:
                translation = "饑餓 2";
                break;
            case STARVING:
                translation = "餓 1";
                break;
            case RAVENOUS:
                translation = "飢餓 0";
                break;
            default:
                translation = "未知";
                break;
        }

        return translation;
    }


    public String getCatEmotionTranslation( ) {
        String translation;

        switch (currentEmotion) {
            case SATISFIED:
                translation = "滿足 4";
                break;
            case PLAYFUL:
                translation = "好玩 3";
                break;
            case DISSATISFIED:
                translation = "不滿 2";
                break;
            case FEARFUL:
                translation = "恐懼 1";
                break;
            case ANXIOUS:
                translation = "焦慮 0";
                break;
            default:
                translation = "未知";
                break;
        }

        return translation;
    }

    public  void setCoin() {
        Random random = new Random();
        coinNum = random.nextInt(51) + 50; // Generate random number between 50 and 100 (inclusive)
    }
    public void setEmotion(){
        int remainder = coinNum % 5;
        switch (remainder) {
            case 0:
                currentEmotion = CatEmotion.SATISFIED;
                break;
            case 1:
                currentEmotion = CatEmotion.PLAYFUL;
                break;
            case 2:
                currentEmotion = CatEmotion.DISSATISFIED;
                break;
            case 3:
                currentEmotion = CatEmotion.FEARFUL;
                break;
            case 4:
                currentEmotion = CatEmotion.ANXIOUS;
                break;
        }

    }


    public void setHunger(){
        int remainder = coinNum % 5;
        switch (remainder) {
            case 0:
                currentHungerLevel = HungerLevel.SATIATED;
                break;
            case 1:
                currentHungerLevel = HungerLevel.SATISFIED;
                break;
            case 2:
                currentHungerLevel = HungerLevel.HUNGRY;
                break;
            case 3:
                currentHungerLevel = HungerLevel.STARVING;
                break;
            case 4:
                currentHungerLevel = HungerLevel.RAVENOUS;
                break;
        }
    }
    public enum CatEmotion {
        SATISFIED(4),
        PLAYFUL(3),
        DISSATISFIED(2),
        FEARFUL(1),
        ANXIOUS(0);

        private final int value;

        CatEmotion(int value) {
            this.value = value;
        }

        public int getValue() {
            return value;
        }
    }

    public CatEmotion increaseCatEmotion(CatEmotion currentEmotion) {
        if (currentEmotion == CatEmotion.ANXIOUS) {
            return CatEmotion.FEARFUL;
        } else if (currentEmotion == CatEmotion.FEARFUL) {
            return CatEmotion.DISSATISFIED;
        } else if (currentEmotion == CatEmotion.DISSATISFIED) {
            return CatEmotion.PLAYFUL;
        } else if (currentEmotion == CatEmotion.PLAYFUL) {
            return CatEmotion.SATISFIED;
        } else {
            // Handle the case when currentEmotion is SATISFIED
            // You can either return SATISFIED or perform a specific action
            return currentEmotion;  // Returning the same emotion in this example
        }
    }

    public CatEmotion decreaseCatEmotion(CatEmotion currentEmotion) {
        if (currentEmotion == CatEmotion.SATISFIED) {
            return CatEmotion.PLAYFUL;
        } else if (currentEmotion == CatEmotion.PLAYFUL) {
            return CatEmotion.DISSATISFIED;
        } else if (currentEmotion == CatEmotion.DISSATISFIED) {
            return CatEmotion.FEARFUL;
        } else if (currentEmotion == CatEmotion.FEARFUL) {
            return CatEmotion.ANXIOUS;
        } else {
            // Handle the case when currentEmotion is ANXIOUS
            // You can either return ANXIOUS or perform a specific action
            return currentEmotion;  // Returning the same emotion in this example
        }
    }


    /*public CatEmotion increaseCatEmotion(CatEmotion currentEmotion) {
        int currentValue = currentEmotion.getValue();
        if (currentValue == 4) {
            return currentEmotion;  // Don't let it increase if already at maximum level
        } else{
            int nextValue = currentValue++;
            return CatEmotion.values()[nextValue];
        }
    }

    public CatEmotion decreaseCatEmotion(CatEmotion currentEmotion) {
        int currentValue = currentEmotion.getValue();
        if (currentValue == 0) {
            return currentEmotion;  // Don't let it decrease if already at minimum level
        } else {
            int previousValue = currentValue--;
            return CatEmotion.values()[previousValue];
        }
    }*/




    public enum HungerLevel {
        SATIATED(4),
        SATISFIED(3),
        HUNGRY(2),
        STARVING(1),
        RAVENOUS(0);

        private final int value;

        HungerLevel(int value) {
            this.value = value;
        }

        public int getValue() {
            return value;
        }
    }


    public HungerLevel increaseHungerLevel(HungerLevel currentHungerLevel) {
        if (currentHungerLevel == HungerLevel.RAVENOUS) {
            return HungerLevel.STARVING;
        } else if (currentHungerLevel == HungerLevel.STARVING) {
            return HungerLevel.HUNGRY;
        } else if (currentHungerLevel == HungerLevel.HUNGRY) {
            return HungerLevel.SATISFIED;
        } else if (currentHungerLevel == HungerLevel.SATISFIED) {
            return HungerLevel.SATIATED;
        } else {
            // Handle the case when currentHungerLevel is SATIATED
            // You can either return SATIATED or perform a specific action
            return currentHungerLevel;  // Returning the same level in this example
        }
    }

    /*public HungerLevel increaseHungerLevel(HungerLevel currentHungerLevel) {
        int currentValue = currentHungerLevel.getValue();
        Log.d("Debug", getHungerLevelTranslation() + "old");
        if (currentValue == 4) {
            return currentHungerLevel;  // Don't let it increase if already at maximum level
        } else {
            int nextValue = currentValue++;
            Log.d("Debug", getHungerLevelTranslation() + "new");
            return HungerLevel.values()[nextValue];
        }
    }*/

    /*public HungerLevel decreaseHungerLevel(HungerLevel currentHungerLevel) {
        Log.d("Debug", getHungerLevelTranslation() + "old");
        int currentValue = currentHungerLevel.getValue();
        if (currentValue == 0) {
            return currentHungerLevel;  // Don't let it decrease if already at minimum level
        } else {
            int previousValue = currentValue--;
            Log.d("Debug", getHungerLevelTranslation() + "new");
            return HungerLevel.values()[previousValue];
        }
    }*/

    public HungerLevel decreaseHungerLevel(HungerLevel currentHungerLevel) {
        if (currentHungerLevel == HungerLevel.SATIATED) {
            return HungerLevel.SATISFIED;
        } else if (currentHungerLevel == HungerLevel.SATISFIED) {
            return HungerLevel.HUNGRY;
        } else if (currentHungerLevel == HungerLevel.HUNGRY) {
            return HungerLevel.STARVING;
        } else if (currentHungerLevel == HungerLevel.STARVING) {
            return HungerLevel.RAVENOUS;
        } else {
            // Handle the case when currentHungerLevel is RAVENOUS
            // You can either return RAVENOUS or perform a specific action
            return currentHungerLevel;  // Returning the same level in this example
        }
    }


}