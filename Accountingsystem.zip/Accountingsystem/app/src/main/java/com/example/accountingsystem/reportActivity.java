package com.example.accountingsystem;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.material.tabs.TabLayout;

public class reportActivity extends AppCompatActivity {
    private ViewPager viewPager;
    private Button increaseMonthBtn, decreaseMonthBtn;
    private TextView tvCurrentDate;
    private ViewPager2Adapter adapter;
    private  Account account;
    //private String[] tabTitles = {"收入", "支出"};
    private TabLayout tablayout;
    private myDate date = new myDate();

    private expenseact expenseact;
    private incomeact incomeact;
    private  Fragment expenseFrg, incomeFrg;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.report_date_selecter);
        Intent intent = getIntent();
        account = (Account) intent.getSerializableExtra("account");
        //expenseFrg = (new expenseact(account,date));

        increaseMonthBtn = findViewById(R.id.increaseMonthBtn);
        decreaseMonthBtn = findViewById(R.id.decreaseMonthBtn);
        tvCurrentDate = findViewById(R.id.tvCurrentDate);
        tvCurrentDate.setText(date.toMonthString());
        expenseact = new expenseact(account,date);
        incomeact = new incomeact(account,date);
        increaseMonthBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //adapter.cleanList();
                date.increaseMonth();
                expenseact.refreshPieChart();
                incomeact.refreshPieChart();
                //expenseFrg = (new expenseact(account,date));
                tvCurrentDate.setText(date.toMonthString());
            }
        });
        decreaseMonthBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                date.decreaseMonth();
                expenseact.refreshPieChart();
                incomeact.refreshPieChart();
                tvCurrentDate.setText(date.toMonthString());
            }
        });

        adapter = new ViewPager2Adapter(getSupportFragmentManager());
        adapter.addFragment(incomeact,"收入");
        adapter.addFragment(expenseact,"支出");
        viewPager = findViewById(R.id.viewPagerMain);
        tablayout = findViewById(R.id.tablayout);
        viewPager.setAdapter(adapter);
        viewPager.setOffscreenPageLimit(2);
        tablayout.setupWithViewPager(viewPager);

        tablayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                // Handle tab selection
                viewPager.setCurrentItem(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                // Handle tab unselection
            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {
                // Handle tab reselection
            }
        });


    }



}