package com.example.accountingsystem;
import android.os.Build;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class Clock {
    private LocalTime currentTime;

    public Clock() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            currentTime = LocalTime.now();
        }
    }

    public LocalTime getCurrentTime() {
        return currentTime;
    }

    public String toString() {
        return currentTime.toString();
    }

    public static Clock parseClock(String timeString) {
        LocalTime parsedTime = null;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            parsedTime = LocalTime.parse(timeString);
        }
        Clock clock = new Clock();
        clock.currentTime = parsedTime;
        return clock;
    }

    public boolean compare(Clock otherClock) {
        return currentTime.compareTo(otherClock.getCurrentTime()) > 0;
    }
}
