package com.example.accountingsystem;

public class Budget {

    private int budgetId;
    private Double value=0.0;
    private int reportId;
    public Budget(int budgetId,Double value, int reportId){
        this.budgetId = budgetId;
        this.value = value;
        this.reportId = reportId;
    }

    public  Budget(){}


    public void insertData(DBHelper db){
        int rowId = (int) db.insertBudget(value,reportId);
        if(rowId != -1){
            this.reportId = rowId;
            System.out.println( toString()+ " insert success");
        }
        else{
            System.out.println( toString()+ " insert failed");
        }
    }

    public Budget updateById(DBHelper db, int budgetId, Double value){
        db.updateBudgetById(budgetId,value);
        Budget budget = db.getBudgetById(budgetId);
        return budget;
    }


    public int getBudgetId() {
        return budgetId;
    }

    public void setBudgetId(int budgetId) {
        this.budgetId = budgetId;
    }

    public double getValue() {
        return value;
    }

    public void setValue(double value) {
        this.value = value;
    }

    public int getReportId() {
        return reportId;
    }

    public void setReportId(int reportId) {
        this.reportId = reportId;
    }

    @Override
    public String toString() {
        return "Budget ID: " + budgetId +
                "\nBudget value: " + value +
                "\nReport ID: " + reportId;
    }


}
