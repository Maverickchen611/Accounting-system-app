package com.example.accountingsystem;

public class Logout  extends Account{

    public void setLogoutStatus(){
       loginStatus = false;
    }
}
