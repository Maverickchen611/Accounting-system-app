package com.example.accountingsystem;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;


import com.github.mikephil.charting.animation.Easing;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.highlight.Highlight;
import com.github.mikephil.charting.listener.OnChartValueSelectedListener;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;


public class MainActivity extends AppCompatActivity {
    private String inputText = "";
    private PieChart pieChart;
    private Button increaseMonthBtn, decreaseMonthBtn,datePickerButton,
            ConfirmBtn, expensebtn,incomebtn, selectBtn,deleteBtn,petBtn;
    private TextView tvCurrentDate;
    private Button reportBtn;
    DBHelper dbHelper;
    private LayoutInflater inflater,exinflater,barinflater ;
    private View dialogView,exdialogView;
    private AlertDialog createIncomeDialog,createExpenseDialog, selectDialog;
    //private AlertDialog barDialog;
    private myDate date=new myDate();
    private TextView edDate;
    private LinearLayout mainLinearLayout;
    private List<View> addedViews;
    private Account account;

    private int coinNum=0;
    private Income currentIncome;
    private Expense currentExpense;
    private boolean chooseIncome, updateMode;
    private ProgressBar bar;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initialLayout();
        setButtonClickListener();
        initPieChart();

        pieChart.getDescription().setEnabled(false);
        pieChart.setDrawEntryLabels(true);

        if(account == null){ startLoginActivity();}
        else{
            date = new myDate();
            createList();


            //date = date.parseDate("2023/6/4");


            //
            //Button btnPositive = dialogView.findViewById(R.id.incomeConfirmBtn);
            //Button csDatePickerButton = findViewById(R.id.datePickerButton);
            //Button btnNegative = dialogView.findViewById(R.id.btn_negative);
            //
            //dialog.show();

            //account = new Account("test1", "pass");
            //account.insertData(dbHelper);

            //Report report1 = account.createAndInsertReport(dbHelper, new myDate());
            //Report report1 = account.getReportsByAccountIdAndDate(dbHelper,account.getAccountId(), date.toMonthString());
            //report1.createAndInsertIncome(dbHelper,date,"food","breakfast",45,"sandwich");


            //report1.createAndInsertIncome(dbHelper, "food","launch",90,"vegan house");
        /*
        Report report2 = account.getReportsByAccountIdAndDate(dbHelper, account.getAccountId(), "2023/6");
        report2.setIncomeByReportId(dbHelper, report2.getReportId());
        System.out.println(report2.toString());*/



        /*LinearLayout linearLayout = findViewById(R.id.linear); // Assuming you have a LinearLayout with id "linearLayout" in your layout
        LayoutInflater itemTemplateInflater = getLayoutInflater();
        View itemTemplateView = itemTemplateInflater.inflate(R.layout.item_templete_1,null);
        LinearLayout itemTemplateLinearLayout = itemTemplateView.findViewById(R.id.itemTemplateLinaer);
        int numberOfTextViews = 50; // The number of TextView instances you want to create

        for (int i = 0; i < numberOfTextViews; i++) {
            TextView textView = new TextView(this);
            textView.setText("TextView " + (i + 1)); // Set the text for the TextView

            // Add any additional configurations for the TextView (e.g., text color, size, etc.)

            linearLayout.addView(itemTemplateLinearLayout); // Add the TextView to the LinearLayout
        }*/

        }



    }




    private void startLoginActivity() {
        Intent intent = new Intent(MainActivity.this, LoginAct.class);
        someActivityResultLauncher.launch(intent);
    }
    private final ActivityResultLauncher<Intent> someActivityResultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == Activity.RESULT_OK) {
                    Intent data = result.getData();
                    // Handle the result returned from OtherActivity
                    account = (Account) data.getSerializableExtra("RESULT_ACCOUNT");
                    createList();
                    setbudget();
                    showPieChart(summarize());
                    Toast.makeText(this, "Received result: " + account.toString(), Toast.LENGTH_SHORT).show();
                }
            }
    );




    private void createList(){
        LayoutInflater itemTemplateInflater = getLayoutInflater();
        Report tmpReport = account.getReportsByAccountIdAndDate(dbHelper,account.getAccountId(),date.toMonthString());
        System.out.println(tmpReport.toString());

        tmpReport.setIncomeListByReportIdAndDate(dbHelper,date.toString());
        tmpReport.setExpenseListByReportIdAndDate(dbHelper,date.toString());
        List<Income> tmpIncomeList = tmpReport.getIncomeList();
        List<Expense> tmpExpenseList = tmpReport.getExpenseList();

        if(tmpIncomeList.isEmpty()&& tmpExpenseList.isEmpty()){
            addedViews = new ArrayList<>();
            View itemTemplateView = itemTemplateInflater.inflate(R.layout.item_template_1, null);
            //LinearLayout itemLinearLayout = itemTemplateView.findViewById(R.id.itemTemplateLinaer);
            // Find the TextViews in the inflated layout
            TextView topLeftTextView = itemTemplateView.findViewById(R.id.top_left);
            TextView bottomLeftTextView = itemTemplateView.findViewById(R.id.bottom_left);
            TextView topRightTextView = itemTemplateView.findViewById(R.id.top_right);
            TextView bottomRightTextView = itemTemplateView.findViewById(R.id.bottom_right);

            // Set the desired text for each TextView
            System.out.println("no data in "+date.toString());
            topLeftTextView.setText("no data");
            bottomLeftTextView.setText("no data");
            topRightTextView.setText("no data");
            bottomRightTextView.setText("no data");
            addedViews.add(itemTemplateView);
            mainLinearLayout.addView(itemTemplateView); // Add the itemTemplateView to the linearLayout

        }
        else {
            addedViews = new ArrayList<>();
        }
        int IncomeCount = tmpIncomeList.size()-1;
        int ExpenseCount = tmpExpenseList.size()-1;
        boolean incomeAvailable = false;
        boolean expenseAvailable = false;
        while(IncomeCount >-1 ||  ExpenseCount >-1){
            System.out.println("IncomeCount: "+ IncomeCount);
            System.out.println("ExpenseCount: "+ ExpenseCount);
            View itemTemplateViewIncome = itemTemplateInflater.inflate(R.layout.item_template_1, null);

            TextView topLeftTextViewIncome = itemTemplateViewIncome.findViewById(R.id.top_left);
            TextView bottomLeftTextViewIncome = itemTemplateViewIncome.findViewById(R.id.bottom_left);
            TextView topRightTextViewIncome = itemTemplateViewIncome.findViewById(R.id.top_right);
            TextView bottomRightTextViewIncome = itemTemplateViewIncome.findViewById(R.id.bottom_right);

            View itemTemplateViewExpense = itemTemplateInflater.inflate(R.layout.item_template_3, null);

            TextView topLeftTextViewExpense = itemTemplateViewExpense.findViewById(R.id.top_left);
            TextView bottomLeftTextViewExpense = itemTemplateViewExpense.findViewById(R.id.bottom_left);
            TextView topRightTextViewExpense = itemTemplateViewExpense.findViewById(R.id.top_right);
            TextView bottomRightTextViewExpense = itemTemplateViewExpense.findViewById(R.id.bottom_right);
            //LinearLayout itemLinearLayout = itemTemplateViewIncome.findViewById(R.id.itemTemplateLinaer);
            Income tmpIncome = new Income();
            Expense tmpExpense = new Expense();
            if(IncomeCount >-1 && ExpenseCount >-1){
                tmpIncome= tmpIncomeList.get(IncomeCount);
                tmpExpense = tmpExpenseList.get(ExpenseCount);

                if(tmpIncome.getTime().compare(tmpExpense.getTime()) ){ //income later == true
                    incomeAvailable = true;
                    expenseAvailable = false;
                    IncomeCount--;
                }
                else{
                    incomeAvailable = false;
                    expenseAvailable = true;
                    ExpenseCount--;

                }

            }
            else if (  ExpenseCount >= 0 && ExpenseCount < tmpExpenseList.size() ) {
                tmpExpense = tmpExpenseList.get(ExpenseCount);
                ExpenseCount--;
                incomeAvailable = false;
                expenseAvailable = true;

            }
            else if ( IncomeCount >= 0 && IncomeCount < tmpIncomeList.size()) {
                tmpIncome = tmpIncomeList.get(IncomeCount);
                IncomeCount--;
                incomeAvailable = true;
                expenseAvailable = false;

            }
            if(incomeAvailable){
                // Set the desired text for each TextView
                System.out.println(tmpIncome.toString());
                topLeftTextViewIncome.setText(tmpIncome.getDate().toString());
                bottomLeftTextViewIncome.setText(tmpIncome.getCategory()+" - "+ tmpIncome.getItem());
                topRightTextViewIncome.setVisibility(View.INVISIBLE);
                topRightTextViewIncome.setText(String.valueOf(tmpIncome.getIncomeId()));
                bottomRightTextViewIncome.setTextColor(ContextCompat.getColor(this, R.color.green));
                bottomRightTextViewIncome.setText("+"+Double.toString(tmpIncome.getAmount()));

                //itemLinearLayout.setBackgroundColor(ContextCompat.getColor(this, R.color.pink));
                mainLinearLayout.addView(itemTemplateViewIncome); // Add the itemTemplateViewIncome to the linearLayout
                addedViews.add(itemTemplateViewIncome);
            } else if(expenseAvailable) {
                // Set the desired text for each TextView
                System.out.println(tmpExpense.toString());
                topLeftTextViewExpense.setText(tmpExpense.getDate().toString());
                bottomLeftTextViewExpense.setText(tmpExpense.getCategory()+" - "+ tmpExpense.getItem());
                topRightTextViewExpense.setVisibility(View.INVISIBLE);
                topRightTextViewExpense.setText(String.valueOf(tmpExpense.getExpenseId()));
                bottomRightTextViewExpense.setTextColor((ContextCompat.getColor(this, R.color.dark_red)));
                bottomRightTextViewExpense.setText("-"+Double.toString(tmpExpense.getAmount()));

                //itemLinearLayout.setBackgroundColor(ContextCompat.getColor(this, R.color.pink));
                mainLinearLayout.addView(itemTemplateViewExpense); // Add the itemTemplateViewExpense to the linearLayout
                addedViews.add(itemTemplateViewExpense);
            }
        }
        setButtonClickListener();
    }
    private void releaseList(){
        if(addedViews == null){
            return;
        }
        for (int i = 0; i < addedViews.size(); i++) {
            View viewToRemove = addedViews.get(i);
            mainLinearLayout.removeView(viewToRemove);
        }
        addedViews = null;
    }
    private Map<String, Double> getIncomeListToMap(){
        Map<String,Double> tmpMap = new HashMap<>();
        Report tmpReport = account.getReportsByAccountIdAndDate(dbHelper,account.getAccountId(),date.toMonthString());
        List<Income> tmpIncomeList = tmpReport.getIncomeByReportId(dbHelper, tmpReport.getReportId());
        for(int i =0; i< tmpIncomeList.size(); i++){
            Income tmpIncome = tmpIncomeList.get(i);
            String category = tmpIncome.getCategory();
            double amount = tmpIncome.getAmount();
            if(tmpMap.containsKey(category)){
                amount = tmpMap.get(category) + amount;
            }
            tmpMap.put(category, amount);
        }
        return tmpMap;
    }

    private Map<String, Double> getExpenseListToMap(){
        Map<String,Double> tmpMap = new HashMap<>();
        Report tmpReport = account.getReportsByAccountIdAndDate(dbHelper,account.getAccountId(),date.toMonthString());
        List<Expense> tmpExpenseList = tmpReport.getExpenseByReportId(dbHelper, tmpReport.getReportId());
        for(int i =0; i< tmpExpenseList.size(); i++){
            Expense tmpExpense = tmpExpenseList.get(i);
            String category = tmpExpense.getCategory();
            double amount = tmpExpense.getAmount();
            if(tmpMap.containsKey(category)){
                amount = tmpMap.get(category) + amount;
            }
            tmpMap.put(category, amount);
        }
        return tmpMap;
    }

    private Map<String, Double> summarize(){

        Map<String, Double> tmpMap = new HashMap<>();
        Double incomeTotal =incomeTotal();
        Double expenseTotal =expenseTotal();

        tmpMap.put("Income",incomeTotal);
        tmpMap.put("Expense",expenseTotal);
        if(incomeTotal==0.0 && expenseTotal ==0.0) {
            ((TextView) this.findViewById(R.id.balance)).setText("no income \n and expense");
        }else{
            ((TextView) this.findViewById(R.id.balance)).setText(Double.toString(incomeTotal - expenseTotal));
        }
        return tmpMap;

    }

    private Double expenseTotal(){
        Map<String, Double> expenseMap = getExpenseListToMap();
        Double expenseTotal =0.0;
        for (Map.Entry<String, Double> entry : expenseMap.entrySet()) {
            Double value = entry.getValue();
            expenseTotal += value;
        }
        return  expenseTotal;
    }

    private Double incomeTotal(){
        Map<String, Double> incomeMap = getIncomeListToMap();
        Double incomeTotal =0.0;
        for (Map.Entry<String, Double> entry : incomeMap.entrySet()) {

            Double value = entry.getValue();
            incomeTotal += value;
        }
        return  incomeTotal;
    }





    private void setButtonClickListener() {

        increaseMonthBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int tmpMonth = date.getMonth();
                date.increaseDay();
                if(tmpMonth != date.getMonth()){
                    showPieChart(summarize());
                    setbudget();
                }
                tvCurrentDate.setText(date.toString());



                releaseList();
                createList();

                //showPieChart(summarize());
            }
        });
        decreaseMonthBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int tmpMonth = date.getMonth();
                //Toast.makeText(getApplicationContext(),tmpMonth+" " + date.toString(),Toast.LENGTH_SHORT).show();
                date.decreaseDay();

                Report tmpReport = account.getReportsByAccountIdAndDate(dbHelper,account.getAccountId(), date.toMonthString());
                Budget tmpBudget = tmpReport.getBudgetByReportId(dbHelper,tmpReport.getReportId());

                //Toast.makeText(getApplicationContext(),tmpMonth+" " + date.toString(),Toast.LENGTH_SHORT).show();
                if(tmpMonth!= date.getMonth()){
                    setbudget();
                    showPieChart(summarize());
                }
                tvCurrentDate.setText(date.toString());
                releaseList();
                createList();
            }
        });

        selectBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ((TextView) dialogView.findViewById(R.id.tvDate)).setText(date.toString());
                ((EditText) dialogView.findViewById(R.id.edCategory)).setText("");
                ((EditText) dialogView.findViewById(R.id.edItem)).setText("");
                ((EditText) dialogView.findViewById(R.id.edAmount)).setText("");
                ((EditText) dialogView.findViewById(R.id.edDescription)).setText("");
                ((TextView) dialogView.findViewById(R.id.tvErrorMsg)).setText("");
                deleteBtn.setVisibility(View.INVISIBLE);
                updateMode = false;
                selectDialog.show();
            }
        });
        incomebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ViewGroup parent = (ViewGroup) dialogView.getParent();
                if (parent != null) {
                    parent.removeView(dialogView);
                }
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setTitle("新增收入")
                        .setView(dialogView);
                createIncomeDialog = builder.create();

                ((TextView) dialogView.findViewById(R.id.tvErrorMsg)).setText("");
                chooseIncome = true;
                updateMode = false;
                selectDialog.dismiss();
                createIncomeDialog.show();
            }
        });
        expensebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ViewGroup parent = (ViewGroup) dialogView.getParent();
                if (parent != null) {
                    parent.removeView(dialogView);
                }
                AlertDialog.Builder builder2 = new AlertDialog.Builder(MainActivity.this);
                builder2.setTitle("新增支出")
                        .setView(dialogView);
                createExpenseDialog = builder2.create();
                ((TextView) dialogView.findViewById(R.id.tvErrorMsg)).setText("");
                chooseIncome = false;
                updateMode = false;
                selectDialog.dismiss();

                createExpenseDialog.show();
            }
        });
        datePickerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar calendar = Calendar.getInstance();
                int year = calendar.get(Calendar.YEAR);
                int month = calendar.get(Calendar.MONTH);
                int dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);
                // Create a DatePickerDialog and set the current date as the initial date
                DatePickerDialog datePickerDialog = new DatePickerDialog(view.getContext(), new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        // Handle the selected date
                        // You can update your UI or perform any necessary operations
                        String selectedDate = year + "/" + (month+1) + "/" + dayOfMonth;
                        // Do something with the selected date
                        edDate.setText(selectedDate);
                    }
                }, date.getYear(), date.getMonth()-1, date.getDay());
                //}, year, month, dayOfMonth);
                // Show the date picker dialog
                datePickerDialog.show();
            }
        });
        tvCurrentDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar calendar = Calendar.getInstance();
                int year = calendar.get(Calendar.YEAR);
                int month = calendar.get(Calendar.MONTH);
                int dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);
                // Create a DatePickerDialog and set the current date as the initial date
                DatePickerDialog datePickerDialog = new DatePickerDialog(view.getContext(), new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        // Handle the selected date
                        // You can update your UI or perform any necessary operations
                        String selectedDate = year + "/" + (month+1) + "/" + dayOfMonth;
                        // Do something with the selected date
                        date = new myDate().parseDate(selectedDate);
                        tvCurrentDate.setText(selectedDate);
                        releaseList();
                        createList();
                        setbudget();
                        showPieChart(summarize());
                    }
                }, date.getYear(), date.getMonth()-1, date.getDay());
                //}, year, month, dayOfMonth);
                // Show the date picker dialog
                datePickerDialog.show();

            }
        });

        ConfirmBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int id = -1;
                if(updateMode){
                    if(chooseIncome){id = currentIncome.getIncomeId();}
                    else{id = currentExpense.getExpenseId();}
                }
                String tmpDate =((TextView) dialogView.findViewById(R.id.tvDate)).getText().toString();
                myDate date = new myDate().parseDate (tmpDate);
                String category = ((EditText) dialogView.findViewById(R.id.edCategory)).getText().toString();
                String item = ((EditText) dialogView.findViewById(R.id.edItem)).getText().toString();
                String tmpAmount = ((EditText) dialogView.findViewById(R.id.edAmount)).getText().toString();
                String description = ((EditText) dialogView.findViewById(R.id.edDescription)).getText().toString();
                if(storeData(view,account,id ,tmpDate,date,category,item,tmpAmount,description)) {
                    if(chooseIncome) {
                        createIncomeDialog.dismiss();
                    }else {
                        createExpenseDialog.dismiss();
                    }
                    releaseList();
                    createList();
                    showPieChart(summarize());
                    setbudget();
                    ((TextView) dialogView.findViewById(R.id.tvDate)).setText("");
                    ((EditText) dialogView.findViewById(R.id.edCategory)).setText("");
                    ((EditText) dialogView.findViewById(R.id.edItem)).setText("");
                    ((EditText) dialogView.findViewById(R.id.edAmount)).setText("");
                    ((EditText) dialogView.findViewById(R.id.edDescription)).setText("");
                    ((TextView) dialogView.findViewById(R.id.tvErrorMsg)).setText("");
                    Random random = new Random();
                    int r = random.nextInt(50) + 1;
                    coinNum+=r;
                }
                else{
                    ((TextView) dialogView.findViewById(R.id.tvErrorMsg)).setText("Invalid input");
                }

            }
        });

        if(addedViews != null) {
            for (View view : addedViews) {

                view.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v)
                    {
                        TextView topRightTextView = view.findViewById(R.id.top_right);
                        if(topRightTextView.getText().toString().equals("no data")){return;}

                        updateMode = true;
                        deleteBtn.setVisibility(View.VISIBLE);
                        ((TextView) dialogView.findViewById(R.id.tvErrorMsg)).setText("");
                        Log.d("OnClickListener", "onClick called");
                        int id = Integer.parseInt(topRightTextView.getText().toString());
                        TextView bottomRightTextView = view.findViewById(R.id.bottom_right);
                        double amount  = Double.parseDouble(bottomRightTextView.getText().toString());
                        ViewGroup parent = (ViewGroup) dialogView.getParent();
                        if (parent != null) {
                            parent.removeView(dialogView);
                        }
                        if(amount > 0){

                            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                            builder.setTitle("新增收入")
                                    .setView(dialogView);
                            createIncomeDialog = builder.create();

                            chooseIncome = true;
                            currentIncome = new Income().getIncomeById(dbHelper, id);
                            System.out.println(currentIncome.toString());
                            ((TextView) dialogView.findViewById(R.id.tvDate)).setText(currentIncome.getDate().toString());
                            ((EditText) dialogView.findViewById(R.id.edCategory)).setText(currentIncome.getCategory());
                            ((EditText) dialogView.findViewById(R.id.edItem)).setText(currentIncome.getItem());
                            ((EditText) dialogView.findViewById(R.id.edAmount)).setText(Double.toString(currentIncome.getAmount()));
                            ((EditText) dialogView.findViewById(R.id.edDescription)).setText(currentIncome.getDescription());
                            createIncomeDialog.show();
                        }else{
                            AlertDialog.Builder builder2 = new AlertDialog.Builder(MainActivity.this);
                            builder2.setTitle("新增支出")
                                    .setView(dialogView);
                            createExpenseDialog = builder2.create();
                            chooseIncome = false;
                            currentExpense = new Expense().getExpenseById(dbHelper, id);
                            System.out.println(currentExpense.toString());
                            ((TextView) dialogView.findViewById(R.id.tvDate)).setText(currentExpense.getDate().toString());
                            ((EditText) dialogView.findViewById(R.id.edCategory)).setText(currentExpense.getCategory());
                            ((EditText) dialogView.findViewById(R.id.edItem)).setText(currentExpense.getItem());
                            ((EditText) dialogView.findViewById(R.id.edAmount)).setText(Double.toString(currentExpense.getAmount()));
                            ((EditText) dialogView.findViewById(R.id.edDescription)).setText(currentExpense.getDescription());
                            createExpenseDialog.show();
                        }
                    }
                });
            }
        }
        deleteBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                deleteBtn.setVisibility(View.INVISIBLE);
                if(chooseIncome) {
                    createIncomeDialog.dismiss();
                }else {
                    createExpenseDialog.dismiss();
                }
                if(updateMode && chooseIncome) {
                    if (dbHelper.deleteIncomeData(currentIncome.getIncomeId())) {
                        System.out.print("Income delete success");
                    }
                }
                else if(updateMode){
                    if(dbHelper.deleteExpenseData(currentExpense.getExpenseId())){
                        System.out.print("Expense delete success");
                    }
                }else{
                    System.out.print("Error, in create mode click deleteBtn");
                }
                ((EditText) dialogView.findViewById(R.id.edCategory)).setText("");
                ((EditText) dialogView.findViewById(R.id.edItem)).setText("");
                ((EditText) dialogView.findViewById(R.id.edAmount)).setText("");
                ((EditText) dialogView.findViewById(R.id.edDescription)).setText("");
                ((TextView) dialogView.findViewById(R.id.tvErrorMsg)).setText("");
                releaseList();
                createList();
                showPieChart(summarize());
                setbudget();
            }
        });
        /*
        ViewGroup parentView = (ViewGroup) pieChart.getParent();
        parentView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity.this, "Received result: ", Toast.LENGTH_SHORT).show();
            }
        });
         */
        bar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setTitle("Enter Budget value");
                EditText editText = new EditText(MainActivity.this);
                editText.setInputType(InputType.TYPE_CLASS_NUMBER);

                Report tmpReport = account.getReportsByAccountIdAndDate(dbHelper,account.getAccountId(), date.toMonthString());
                Budget tmpBudget = tmpReport.getBudgetByReportId(dbHelper,tmpReport.getReportId());
                //System.out.println(tmpBudget.toString());
                if(tmpBudget != null){
                    editText.setText(Double.toString(tmpBudget.getValue()));
                }
                builder.setView(editText);
                builder.setPositiveButton("設定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        inputText = editText.getText().toString();
                        if(inputText.equals("")){return;}
                        Report tmpReport = account.getReportsByAccountIdAndDate(dbHelper,account.getAccountId(), date.toMonthString());
                        Budget tmpBudget = tmpReport.getBudgetByReportId(dbHelper,tmpReport.getReportId());
                        //System.out.println(tmpBudget.toString());
                        if(tmpBudget == null){
                            tmpBudget = tmpReport.createAndInsertBudget(dbHelper, Double.parseDouble(inputText));
                        }else{
                            tmpBudget = tmpBudget.updateById(dbHelper,tmpBudget.getBudgetId(),Double.parseDouble(inputText) );
                        }

                        setbudget();
                    }
                });
                builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });
        reportBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Toast.makeText(getApplicationContext(),"123",Toast.LENGTH_SHORT).show();

                Intent intent = new Intent(MainActivity.this, reportActivity.class);

                // Add any extra data to the intent if needed
                intent.putExtra("account", account);

                // Start the new activity
                startActivity(intent);
            }
        });
        petBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                startPetActivity();
                /*//Toast.makeText(getApplicationContext(),"123",Toast.LENGTH_SHORT).show();

                Intent intent = new Intent(MainActivity.this, PetActivity.class);

                // Add any extra data to the intent if needed
                //intent.putExtra("account", account);

                // Start the new activity
                startActivity(intent);*/
            }
        });
    }

    private void startPetActivity() {
        Intent intent = new Intent(MainActivity.this, PetActivity.class);
        intent.putExtra("coinNum", coinNum); // Replace "dataKey" with your desired key and "Hello SecondActivity!" with the actual data you want to send
        PetActivityResultLauncher.launch(intent);
    }
    private final ActivityResultLauncher<Intent> PetActivityResultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == Activity.RESULT_OK) {
                    Intent data = result.getData();
                    // Handle the result returned from OtherActivity
                    coinNum = data.getIntExtra("updatedValue", 0);
                    Toast.makeText(this, "Received result: " + Integer.toString(coinNum), Toast.LENGTH_SHORT).show();
                }
            }
    );

    public void startLoginPage(){
        Intent intent = new Intent(MainActivity.this, LoginAct.class);
        //intent.putExtra("dbHelper", (Serializable) dbHelper);
        startActivity(intent);
        //finish();
    }

    //view,date,category,item,tmpAmount,description
    private void initialLayout(){
        dbHelper = new DBHelper(MainActivity.this);
        mainLinearLayout = findViewById(R.id.linear); // Assuming you have a LinearLayout with id "linear" in your layout
        inflater = getLayoutInflater();
        dialogView = inflater.inflate(R.layout.create_income_alert, null);
        datePickerButton = dialogView.findViewById(R.id.datePickerButton);
        ConfirmBtn = dialogView.findViewById(R.id.incomeConfirmBtn);
        deleteBtn = dialogView.findViewById(R.id.deleteBtn);
        deleteBtn.setVisibility(View.INVISIBLE);
        exinflater = getLayoutInflater();
        exdialogView = exinflater.inflate(R.layout.select, null);
        incomebtn = exdialogView.findViewById(R.id.exincome);
        expensebtn = exdialogView.findViewById(R.id.exexpense);
        selectBtn = findViewById(R.id.button);
        increaseMonthBtn = findViewById(R.id.increaseMonthBtn);
        decreaseMonthBtn = findViewById(R.id.decreaseMonthBtn);
        tvCurrentDate = findViewById(R.id.tvCurrentDate);
        tvCurrentDate.setText(date.toString());
        reportBtn = findViewById(R.id.reportButton);
        bar = findViewById(R.id.bar);
        petBtn = findViewById(R.id.button2);
        AlertDialog.Builder builder1 = new AlertDialog.Builder(MainActivity.this);
        builder1//.setTitle("選擇愈新增項目")
                .setView(exdialogView);
        selectDialog = builder1.create();

        edDate = dialogView.findViewById(R.id.tvDate);
        edDate.setText(new myDate().toString());



        pieChart = findViewById(R.id.pieChart_view);
        pieChart.setHoleColor(Color.parseColor("#000000"));
        pieChart.setOnChartValueSelectedListener(new PieChartOnChartValueSelectedListener());


    }
    private boolean storeData(View view, Account account,int id, String tmpDate, myDate date, String category, String item, String tmpAmount, String description)
    {
        double amount =0;
        if (tmpAmount.matches("-?\\d+(\\.\\d+)?")) {
            amount = Double.parseDouble(tmpAmount);
        }

        System.out.println("Date: " + date.toString());
        System.out.println("category: " + category);
        System.out.println("item: " + item);
        System.out.println("amount: " + amount);
        System.out.println("description: " + description);
        if( !tmpDate.isEmpty() && !category.isEmpty() && amount!=0 ){
            Report tmpReport = account.getReportsByAccountIdAndDate(dbHelper ,account.getAccountId(), date.toMonthString() ) ;
            if(tmpReport != null){
                System.out.println(tmpReport.toString());
            }else{
                tmpReport = account.createAndInsertReport(dbHelper, date);
            }
            if(!updateMode){
                if(chooseIncome){
                    tmpReport.createAndInsertIncome(dbHelper,date, category, item, amount, description);
                }else{
                    tmpReport.createAndInsertExpense(dbHelper,date, category, item, amount, description);
                }
            }else{
                if(chooseIncome){
                    new Income().updateIncomeById(dbHelper , id ,category,item, amount,description);
                }else{
                    new Expense().updateExpenseById(dbHelper , id ,category,item, amount,description);
                }
            }


            return true;
        }
        return false;
    }
    private void setbudget(){

        Report tmpReport = account.getReportsByAccountIdAndDate(dbHelper,account.getAccountId(), date.toMonthString());
        Budget tmpBudget = tmpReport.getBudgetByReportId(dbHelper,tmpReport.getReportId());
        //System.out.println(tmpBudget.toString());

        int a = 0;
        int b = (int)Math.round(expenseTotal());
        //Toast.makeText(getApplicationContext(),inputText, Toast.LENGTH_SHORT).show();
        if (tmpBudget != null)
        {
            //Toast.makeText(getApplicationContext(),"YES", Toast.LENGTH_SHORT).show();
            a = (int)Math.round(tmpBudget.getValue());
            //Toast.makeText(getApplicationContext(),a + " " + b, Toast.LENGTH_SHORT).show();
            double c = (double)b/a;
            c = c * 100;
            int result = (int)Math.round(c);
            //Toast.makeText(getApplicationContext(),result, Toast.LENGTH_SHORT).show();
            bar.setProgress(result);
            //Toast.makeText(getApplicationContext(),a + " " + b+ " "+ (b/a)*100, Toast.LENGTH_SHORT).show();
            bar.setMax(100);
        }
        else
            bar.setProgress(0);
        /*if (!inputText.equals(""))
        {
            //Toast.makeText(getApplicationContext(),"YES", Toast.LENGTH_SHORT).show();
            a = Integer.parseInt(inputText);
            //Toast.makeText(getApplicationContext(),a + " " + b, Toast.LENGTH_SHORT).show();
            double c = (double)b/a;
            c = c * 100;
            int result = (int)Math.round(c);
            //Toast.makeText(getApplicationContext(),result, Toast.LENGTH_SHORT).show();
            bar.setProgress(result);
            //Toast.makeText(getApplicationContext(),a + " " + b+ " "+ (b/a)*100, Toast.LENGTH_SHORT).show();
            bar.setMax(100);
        }*/
    }
    private void showPieChart(Map<String, Double> typeAmountMap){

        ArrayList<PieEntry> pieEntries = new ArrayList<>();
        String label = "type";
        //typeAmountMap = getIncomeListToMap();
        //initializing data
        if(typeAmountMap.isEmpty()){
            typeAmountMap.put("no Data",1.0);
        }

        /*Map<String, Double> typeAmountMap = new HashMap<>();
        typeAmountMap.put("Toys", 200.0);
        typeAmountMap.put("Snacks", 230.0);
        typeAmountMap.put("Clothes", 100.0);
        typeAmountMap.put("Stationary", 500.0);
        typeAmountMap.put("Phone", 50.0);*/

        //initializing colors for the entries
        ArrayList<Integer> colors = new ArrayList<>();
        colors.add(Color.parseColor("#304567"));
        colors.add(Color.parseColor("#309967"));
        colors.add(Color.parseColor("#476567"));
        colors.add(Color.parseColor("#890567"));
        colors.add(Color.parseColor("#a35567"));
        colors.add(Color.parseColor("#ff5f67"));
        colors.add(Color.parseColor("#3ca567"));

        //input data and fit data into pie chart entry
        for(String type: typeAmountMap.keySet()){
            pieEntries.add(new PieEntry(typeAmountMap.get(type).floatValue(), type));
        }

        //collecting the entries with label name
        PieDataSet pieDataSet = new PieDataSet(pieEntries,label);
        //setting text size of the value
        pieDataSet.setValueTextSize(15f);
        //providing color list for coloring different entries
        pieDataSet.setColors(colors);
        //grouping the data set from entry to chart
        PieData pieData = new PieData(pieDataSet);
        //showing the value of the entries, default true if not set
        pieData.setDrawValues(true);

        pieChart.setData(pieData);
        pieChart.invalidate();

    }

    private void initPieChart(){
        //using percentage as values instead of amount
        pieChart.setUsePercentValues(false);

        //remove the description label on the lower left corner, default true if not set
        pieChart.getDescription().setEnabled(false);

        //enabling the user to rotate the chart, default true
        pieChart.setRotationEnabled(true);
        //Set this to true to draw the entry labels into the pie slices.

        //adding friction when rotating the pie chart
        pieChart.setDragDecelerationFrictionCoef(0.9f);
        //setting the first entry start from right hand side, default starting from top
        pieChart.setRotationAngle(0);

        //highlight the entry when it is tapped, default true if not set
        pieChart.setHighlightPerTapEnabled(true);
        //adding animation so the entries pop up from 0 degree
        pieChart.animateY(1400, Easing.EaseInOutQuad);
        //setting the color of the hole in the middle, default white
        pieChart.setHoleColor(Color.parseColor("#ffffff"));

    }
    private class PieChartOnChartValueSelectedListener implements OnChartValueSelectedListener {

        @Override
        public void onValueSelected(Entry e, Highlight h) {
            // Trigger activities when entry is clicked
        }

        @Override
        public void onNothingSelected() {

        }
    }
}