package com.example.accountingsystem;

import android.graphics.Color;
import android.os.Bundle;

import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.github.mikephil.charting.animation.Easing;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.highlight.Highlight;
import com.github.mikephil.charting.listener.OnChartValueSelectedListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class expenseact extends Fragment {

    DBHelper dbHelper;
    PieChart pieChart;
    Account account;
    Report report;
    myDate date;
    View view;
    private LinearLayout mainLinearLayout;
    private List<View> addedViews;

    public expenseact(Account account, myDate date){
        this.account =account;
        this.date = date;
    }

    public void setDate(myDate date){
        this.date = date;

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        addedViews = new ArrayList<>();

        view = inflater.inflate(R.layout.fragment_expense, container, false);
        mainLinearLayout = view.findViewById(R.id.income_fragment_linear);
        dbHelper = new DBHelper(getActivity());


        Toast.makeText(getContext(), "Received result: " + account.toString(), Toast.LENGTH_SHORT).show();
        refreshPieChart();
        //createList();
        return view;
    }

    private void createList(){
        LayoutInflater itemTemplateInflater = getLayoutInflater();
        Report tmpReport = account.getReportsByAccountIdAndDate(dbHelper,account.getAccountId(),date.toMonthString());
        System.out.println(tmpReport.toString());

        tmpReport.setExpenseByReportId(dbHelper,report.getReportId());
        List<Expense> tmpExpenseList = tmpReport.getExpenseList();

        if(tmpExpenseList.isEmpty()){
            addedViews = new ArrayList<>();
            View itemTemplateView = itemTemplateInflater.inflate(R.layout.item_template_1, null);
            //LinearLayout itemLinearLayout = itemTemplateView.findViewById(R.id.itemTemplateLinaer);
            // Find the TextViews in the inflated layout
            TextView topLeftTextView = itemTemplateView.findViewById(R.id.top_left);
            TextView bottomLeftTextView = itemTemplateView.findViewById(R.id.bottom_left);
            TextView topRightTextView = itemTemplateView.findViewById(R.id.top_right);
            TextView bottomRightTextView = itemTemplateView.findViewById(R.id.bottom_right);

            // Set the desired text for each TextView
            System.out.println("no data in "+date.toString());
            topLeftTextView.setText("no data");
            bottomLeftTextView.setText("no data");
            topRightTextView.setText("no data");
            bottomRightTextView.setText("no data");
            addedViews.add(itemTemplateView);
            mainLinearLayout.addView(itemTemplateView); // Add the itemTemplateView to the linearLayout

        }
        else {
            addedViews = new ArrayList<>();
        }
        int ExpenseCount = tmpExpenseList.size()-1;

        Map<String ,Double> categoryMap = getExpenseListToMap();
        if (!categoryMap.isEmpty()) {
            for (Map.Entry<String, Double> entry : categoryMap.entrySet()) {

                System.out.println("ExpenseCount: " + ExpenseCount);

                View itemTemplateViewExpense = itemTemplateInflater.inflate(R.layout.item_template_3, null);

                TextView topLeftTextViewExpense = itemTemplateViewExpense.findViewById(R.id.top_left);
                TextView bottomLeftTextViewExpense = itemTemplateViewExpense.findViewById(R.id.bottom_left);
                TextView topRightTextViewExpense = itemTemplateViewExpense.findViewById(R.id.top_right);
                TextView bottomRightTextViewExpense = itemTemplateViewExpense.findViewById(R.id.bottom_right);


                String key = entry.getKey();
                Double value = entry.getValue();
                topLeftTextViewExpense.setVisibility(View.GONE);
                topRightTextViewExpense.setVisibility(View.GONE);
                bottomLeftTextViewExpense.setText(key.toString());
                //topRightTextViewExpense.setVisibility(View.INVISIBLE);
                //topRightTextViewExpense.setText("");
                bottomRightTextViewExpense.setTextColor((ContextCompat.getColor(getActivity(), R.color.dark_red)));
                bottomRightTextViewExpense.setText("-" + Double.toString(value));

                //itemLinearLayout.setBackgroundColor(ContextCompat.getColor(this, R.color.pink));
                mainLinearLayout.addView(itemTemplateViewExpense); // Add the itemTemplateViewExpense to the linearLayout
                addedViews.add(itemTemplateViewExpense);

            }
        }

        //setButtonClickListener();
    }

    private void releaseList(){
        if(addedViews == null){
            return;
        }
        for (int i = 0; i < addedViews.size(); i++) {
            View viewToRemove = addedViews.get(i);
            mainLinearLayout.removeView(viewToRemove);
        }
        addedViews = null;
    }
    public void refreshPieChart() {
        releaseList();
        report = new Account().getReportsByAccountIdAndDate(dbHelper,account.getAccountId(), date.toMonthString());
        pieChart = view.findViewById(R.id.pieChart_view);
        pieChart.setHoleColor(Color.parseColor("#000000"));
        pieChart.setOnChartValueSelectedListener(new PieChartOnChartValueSelectedListener());
        initPieChart();
        showPieChart(getExpenseListToMap());
        pieChart.getDescription().setEnabled(false);
        pieChart.setDrawEntryLabels(true);
        createList();
    }

    private Map<String, Double> getExpenseListToMap(){
        Map<String,Double> tmpMap = new HashMap<>();
        List<Expense> tmpExpenseList = report.getExpenseByReportId(dbHelper, report.getReportId());
        for(int i =0; i< tmpExpenseList.size(); i++){
            Expense tmpExpense = tmpExpenseList.get(i);
            String category = tmpExpense.getCategory();
            double amount = tmpExpense.getAmount();
            if(tmpMap.containsKey(category)){
                amount = tmpMap.get(category) + amount;
            }
            tmpMap.put(category, amount);
        }
        return tmpMap;
    }
    private void showPieChart(Map<String, Double> typeAmountMap){

        ArrayList<PieEntry> pieEntries = new ArrayList<>();
        String label = "type";
        //typeAmountMap = getIncomeListToMap();
        //initializing data
        if(typeAmountMap.isEmpty()){
            typeAmountMap.put("no Data",1.0);
        }

        /*Map<String, Double> typeAmountMap = new HashMap<>();
        typeAmountMap.put("Toys", 200.0);
        typeAmountMap.put("Snacks", 230.0);
        typeAmountMap.put("Clothes", 100.0);
        typeAmountMap.put("Stationary", 500.0);
        typeAmountMap.put("Phone", 50.0);*/


        //initializing colors for the entries
        ArrayList<Integer> colors = new ArrayList<>();
        colors.add(Color.parseColor("#304567"));
        colors.add(Color.parseColor("#309967"));
        colors.add(Color.parseColor("#476567"));
        colors.add(Color.parseColor("#890567"));
        colors.add(Color.parseColor("#a35567"));
        colors.add(Color.parseColor("#ff5f67"));
        colors.add(Color.parseColor("#3ca567"));

        //input data and fit data into pie chart entry
        for(String type: typeAmountMap.keySet()){
            pieEntries.add(new PieEntry(typeAmountMap.get(type).floatValue(), type));
        }

        //collecting the entries with label name
        PieDataSet pieDataSet = new PieDataSet(pieEntries,label);
        //setting text size of the value
        pieDataSet.setValueTextSize(12f);
        //providing color list for coloring different entries
        pieDataSet.setColors(colors);
        //grouping the data set from entry to chart
        PieData pieData = new PieData(pieDataSet);
        //showing the value of the entries, default true if not set
        pieData.setDrawValues(true);

        pieChart.setData(pieData);
        pieChart.invalidate();
    }
    private void initPieChart(){
        //using percentage as values instead of amount
        pieChart.setUsePercentValues(true);

        //remove the description label on the lower left corner, default true if not set
        pieChart.getDescription().setEnabled(false);

        //enabling the user to rotate the chart, default true
        pieChart.setRotationEnabled(true);
        //Set this to true to draw the entry labels into the pie slices.

        //adding friction when rotating the pie chart
        pieChart.setDragDecelerationFrictionCoef(0.9f);
        //setting the first entry start from right hand side, default starting from top
        pieChart.setRotationAngle(0);

        //highlight the entry when it is tapped, default true if not set
        pieChart.setHighlightPerTapEnabled(true);
        //adding animation so the entries pop up from 0 degree
        pieChart.animateY(1400, Easing.EaseInOutQuad);
        //setting the color of the hole in the middle, default white
        pieChart.setHoleColor(Color.parseColor("#ffffff"));

    }
    private class PieChartOnChartValueSelectedListener implements OnChartValueSelectedListener {

        @Override
        public void onValueSelected(Entry e, Highlight h) {
            // Trigger activities when entry is clicked
        }

        @Override
        public void onNothingSelected() {

        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {super.onCreate(savedInstanceState);}

}